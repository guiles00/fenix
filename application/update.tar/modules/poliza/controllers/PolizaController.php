<?php
require_once ('IndexController.php');

class Poliza_PolizaController extends Poliza_IndexController
{
	private $_solicitud = null;
	private $_sesion = null;
	private $_usuario = null;
	private $_t_usuario = null;
	
	public function init()
	{

		if ( ! (Zend_Auth::getInstance()->hasIdentity())  ) {

			$this->_helper->redirector('index','login','default');
		}

		$this->_helper->layout->disableLayout();
		$this->_solicitud = new Domain_Poliza();
		$this->_services_simple_crud = new Services_SimpleCrud();
		$this->_sesion = Domain_Sesion::getInstance();
		$this->_usuario = $this->_sesion->getUsuario();
		$this->_t_usuario = $this->_usuario->getTipoUsuario();


		if( $this->_usuario->getAcl()->hasPermission('solicitud') ) {

			//exit('tiene permiso');
		} else {
			//exit('no tiene permiso');
		}
			

		//$logger = Zend_Registry::get('logger');
		//$logger->log($this->_usuario->getEntidad() , Zend_Log::INFO);
			
	}

	public function indexAction()
	{
		$this->_forward('list','solicitud','poliza');

	}

	public function listAction()
	{
		$solicitud = new Domain_Poliza();

		$params = $this->_request->getParams();
		
		if(isset($params['buscar'])){
			$rows = $this->_t_usuario->findPolizaByNumero($params['numero']);
			$this->view->buscar = true;
		}else{
			
			$rows = $this->_t_usuario->getPolizas();
		}
		//echo "dentro del controlador de la poliza";
//echo "<pre>";
//print_r($rows);
		//$rows = $this->_services_simple_crud->getAll($this->_solicitud->getModel());
		$this->view->polizas = $rows;
	}
	public function altaAction()
	{

		//$service_model = new Services_SimpleCrud();
		//$rows = $this->_services_simple_crud->getAll($this->_solicitud->getModel());
		//$this->view->rows = $rows;
	}
	public function altaAutomotoresAction()
	{
		$this->view->monedas = Domain_Helper::getHelperByDominio('moneda');
		$compania = new Domain_Compania();
		$this->view->companias= $compania->getModel()->getTable()->findAll()->toArray();
		$productor = new Domain_Productor();
		$this->view->productores= $productor->getModel()->getTable()->findAll()->toArray();
		
		

		$params = $this->_request->getParams();
		echo "<pre>";
		print_r($params);
		//exit;
		//Trae datos para mostrar en la solicitud

			//Si viene con ID es para guardar y traigo la solicitud con los datos
			if(! empty($params['solicitud_id']) ){
				$solicitud = new Domain_Poliza($params['solicitud_id']);
				$this->view->d_solicitud = $solicitud->getModelPoliza();
				$this->view->d_poliza_valores = $solicitud->getModelPolizaValores();
			}else{
				$solicitud = $this->_solicitud;
			}
			
			//echo"<pre>";
			//print_r($solicitud);
			
			if($params['save']){
						//doy de alta la solicitud
			//primero guardo las tablas asociadas
			$m_poliza_valores = $solicitud->getModelPolizaValores();
			$m_poliza_valores->monto_asegurado=$params['monto_asegurado'];
			$m_poliza_valores->moneda_id=$params['moneda_id'];
			$m_poliza_valores->iva=$params['iva'];
			$m_poliza_valores->prima_comision=$params['prima_comision'];
			$m_poliza_valores->prima_tarifa=$params['prima_tarifa'];
			$m_poliza_valores->premio_compania=$params['premio_compania'];
			//$m_poliza_valores->premio_cliente=$params['premio_cliente'];
			$m_poliza_valores->plus=$params['plus'];
			$m_poliza_valores->save();
			//$m_poliza_valores->poliza_valores_id;

			$m_solicitud = $solicitud->getModelPoliza();
			$m_solicitud->asegurado_id=$params['asegurado_id'];
			$m_solicitud->agente_id=$params['agente_id'];
			$m_solicitud->compania_id=$params['compania_id'];
			$m_solicitud->productor_id=$params['productor_id'];
			$m_solicitud->poliza_valores_id = $m_poliza_valores->poliza_valores_id;

			//Guardo la poliza
			$m_solicitud->save();
			$m_solicitud->numero_solicitud = $m_solicitud->poliza_id ;
			$m_solicitud->save();

			$this->view->d_solicitud = $m_solicitud; 
			$this->view->d_poliza_valores = $m_poliza_valores;
		}
		//$service_model = new Services_SimpleCrud();
		//$rows = $this->_services_simple_crud->getAll($this->_solicitud->getModel());

	}
	public function confirmarPolizaAction(){
		$this->_helper->viewRenderer->setNoRender();
		$params = $this->_request->getParams();
		echo "<pre>";
		print_r($params);
		$solicitud = new Domain_Poliza($params['solicitud_id']);
		$m_solicitud = $solicitud->getModelPoliza();
		$m_solicitud->estado_id=1;
		$m_solicitud->save();

	}
	public function altaTransportesAction()
	{

		//$service_model = new Services_SimpleCrud();
		//$rows = $this->_services_simple_crud->getAll($this->_solicitud->getModel());
		//$this->view->rows = $rows;
	}

	public function viewAction()
	{

		$params = $this->_request->getParams();
		$row = $this->_services_simple_crud
		->getById($this->_solicitud->getModel(),array('primary_key'=>'solicitud_id','value'=>$params['id']));

		$this->view->row = $row;

	}
	public function addAction()
	{
		$params = $this->_request->getParams();
		$values =  array_slice($params,4); //saca la data de mas

		if( isset($params['add']) ){
			$this->_services_simple_crud->save($this->_solicitud->getModel(),$values);
		}

	}
	public function editAction()
	{
		$params = $this->_request->getParams();
		$values =  array_slice($params,3); //saca la data de mas
		$this->_services_simple_crud->save($this->_solicitud->getModel(),$values);
		$this->view->params = $params;


	}
	public function deleteAction()
	{

	}
	public function autocompleteAction(){
		
		echo "Hola";
	}
}
