<?php
class Servicios_Exception_Usuarios_Generic extends Exception
{
	
}