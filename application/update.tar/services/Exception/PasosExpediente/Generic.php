<?php
class Servicios_Exception_PasosExpediente_Generic extends Exception
{
	
}