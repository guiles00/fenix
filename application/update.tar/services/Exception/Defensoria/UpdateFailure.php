<?php
class Servicios_Exception_Defensoria_UpdateFailure extends Servicios_Exception_Defensoria_Generic
{
	
}