<?php
class Servicios_Exception_Defensoria_InsertFailure extends Servicios_Exception_Defensoria_Generic
{
	
}