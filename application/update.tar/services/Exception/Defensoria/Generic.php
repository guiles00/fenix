<?php
class Servicios_Exception_Defensoria_Generic extends Exception
{
	
}