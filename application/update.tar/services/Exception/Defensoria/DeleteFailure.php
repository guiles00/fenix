<?php
class Servicios_Exception_Defensoria_DeleteFailure extends Servicios_Exception_Defensoria_Generic
{
	
}