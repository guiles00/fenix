<?php
class Servicios_Exception_PersonasIurix_UpdateFailure extends Servicios_Exception_PersonasIurix_Generic
{
	
}