<?php
class Servicios_Exception_PersonasIurix_DeleteFailure extends Servicios_Exception_PersonasIurix_Generic
{
	
}