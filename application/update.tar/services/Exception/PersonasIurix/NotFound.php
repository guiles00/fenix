<?php
class Servicios_Exception_PersonasIurix_NotFound extends Servicios_Exception_PersonasIurix_Generic
{
	
}