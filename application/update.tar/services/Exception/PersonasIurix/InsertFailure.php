<?php
class Servicios_Exception_PersonasIurix_InsertFailure extends Servicios_Exception_PersonasIurix_Generic
{
	
}