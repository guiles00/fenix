<?php
class Servicios_Exception_PersonasIurix_ForcedId extends Servicios_Exception_PersonasIurix_Generic
{
	
}