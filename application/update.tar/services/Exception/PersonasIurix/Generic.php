<?php
class Servicios_Exception_PersonasIurix_Generic extends Exception
{
	
}