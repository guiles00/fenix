<?php
class Servicios_Exception_EnlaceIurix_Generic extends Exception
{
	
}