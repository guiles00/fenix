<?php
class Servicios_Exception_Autenticacion_Generic extends Exception
{
	
}