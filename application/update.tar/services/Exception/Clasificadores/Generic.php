<?php
class Servicios_Exception_Clasificadores_Generic extends Exception
{
	
}