<?php
class Servicios_Exception_LotesNotificaciones_Generic extends Exception
{
	
}