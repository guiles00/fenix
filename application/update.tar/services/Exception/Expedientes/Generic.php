<?php
class Servicios_Exception_Expedientes_Generic extends Exception
{
	
}