<?php
class Servicios_Exception_Notificaciones_Generic extends Exception
{
	
}