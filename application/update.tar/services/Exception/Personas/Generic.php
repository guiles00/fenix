<?php
class Servicios_Exception_Personas_Generic extends Exception
{
	
}