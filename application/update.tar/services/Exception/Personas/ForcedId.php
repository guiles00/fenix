<?php
class Servicios_Exception_Personas_ForcedId extends Servicios_Exception_Personas_Generic
{
	
}