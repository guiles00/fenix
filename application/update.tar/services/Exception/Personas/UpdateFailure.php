<?php
class Servicios_Exception_Personas_UpdateFailure extends Servicios_Exception_Personas_Generic
{
	
}