<?php
class Servicios_Exception_Personas_DeleteFailure extends Servicios_Exception_Personas_Generic
{
	
}