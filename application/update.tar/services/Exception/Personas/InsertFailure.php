<?php
class Servicios_Exception_Personas_InsertFailure extends Servicios_Exception_Personas_Generic
{
	
}