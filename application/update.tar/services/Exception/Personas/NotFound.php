<?php
class Servicios_Exception_Personas_NotFound extends Servicios_Exception_Personas_Generic
{
	
}