<?php
class Servicios_Exception_LotesPasos_Generic extends Exception
{
	
}