<?php
class Servicios_Exception_GUI_Generic extends Exception
{
	
}