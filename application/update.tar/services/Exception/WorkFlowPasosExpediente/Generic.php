<?php
class Servicios_Exception_WorkFlowPasosExpediente_Generic extends Exception
{
	
}