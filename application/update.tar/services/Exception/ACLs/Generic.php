<?php
class Servicios_Exception_ACLs_Generic extends Exception
{
	
}