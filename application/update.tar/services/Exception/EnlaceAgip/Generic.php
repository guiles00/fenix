<?php
class Servicios_Exception_EnlaceAgip_Generic extends Exception
{
	
}