<?php
class Servicios_Exception_Postales_Generic extends Exception
{
	
}