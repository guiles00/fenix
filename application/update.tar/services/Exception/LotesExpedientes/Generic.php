<?php
class Servicios_Exception_LotesExpedientes_Generic extends Exception
{
	
}