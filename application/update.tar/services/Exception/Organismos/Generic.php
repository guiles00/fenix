<?php
class Servicios_Exception_Organismos_Generic extends Exception
{
	
}