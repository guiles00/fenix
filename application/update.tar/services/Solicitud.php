<?php
/**
 *
 * @author guiles
 * @param: Objeto Poliza, Datos del POST
 */
class Services_Solicitud
{

	public function saveSolicitudAutomotor($solicitud,$params){

		try {
			//1. Poliza Detalle Automotor
			$m_poliza_detalle = $solicitud->getModelDetalleAutomotor();
			$m_poliza_detalle->anio =$params['anio_automotor'];
			$m_poliza_detalle->marca=$params['marca_automotor'];
			$m_poliza_detalle->tipo=$params['tipo_automotor'];
			$m_poliza_detalle->modelo=$params['modelo_automotor'];
			$m_poliza_detalle->color=$params['color_automotor'];
			$m_poliza_detalle->patente=$params['patente_automotor'];
			$m_poliza_detalle->cilindrada_id=$params['cilindrada_automotor'];
			$m_poliza_detalle->serial_carroceria=$params['serial_c_automotor'];
			$m_poliza_detalle->serial_motor=$params['serial_automotor'];
			$m_poliza_detalle->uso_vehiculo=$params['uso_automotor'];
			$m_poliza_detalle->capacidad_id=$params['capacidad_automotor'];
			$m_poliza_detalle->pasajeros_id=$params['pasajeros_automotor'];
			$m_poliza_detalle->flota_id=$params['flota_automotor'];
			$m_poliza_detalle->fecha_titulo=$params['fecha_titulo_automotor'];
			$m_poliza_detalle->titular=$params['titular_automotor'];
			$m_poliza_detalle->numero_certificado=$params['numero_certificado_automotor'];
			$m_poliza_detalle->estado_luces_id=$params['estado_luces_automotor'];
			$m_poliza_detalle->accesorios=$params['accesorios_automotor'];
			$m_poliza_detalle->estado_motor_id=$params['estado_motor_automotor'];
			$m_poliza_detalle->estado_carroceria_id=$params['estado_carroceria_automotor'];
			$m_poliza_detalle->tipo_combustion_id=$params['tipo_combustion_automotor'];
			$m_poliza_detalle->acreedor_prendario=$params['acreedor_prendario_automotor'];
			$m_poliza_detalle->estado_vehiculo_id=$params['estado_vehiculo_automotor'];
			$m_poliza_detalle->otros=$params['otros_automotor'];
			$m_poliza_detalle->sistema_seguridad_id=$params['sistema_seguridad_automotor'];

			$m_poliza_detalle->save();
		} catch (Exception $e) {
			echo $e->getMessage();
		}

		/*
		 * 2- Poliza Valores
		 */
		try{
		$m_poliza_valores = $solicitud->getModelPolizaValores();
		$m_poliza_valores->monto_asegurado=$params['monto_asegurado'];
		$m_poliza_valores->moneda_id=$params['moneda_id'];
		$m_poliza_valores->iva=$params['iva'];
		$m_poliza_valores->prima_comision=$params['prima_comision'];
		$m_poliza_valores->prima_tarifa=$params['prima_tarifa'];
		$m_poliza_valores->premio_compania=$params['premio_compania'];
		$m_poliza_valores->premio_asegurado=$params['premio_asegurado'];
		$m_poliza_valores->plus=$params['plus'];
		$m_poliza_valores->save();
		}catch (Exception $e) {
			echo $e->getMessage();
		}
		
		try {
			
		
		$m_solicitud = $solicitud->getModelPoliza();
		$m_solicitud->asegurado_id=$params['asegurado_id'];
		$m_solicitud->agente_id=$params['agente_id'];
		$m_solicitud->compania_id=$params['compania_id'];
		$m_solicitud->productor_id=$params['productor_id'];
		$m_solicitud->cobrador_id=$params['cobrador_id'];
		$m_solicitud->fecha_pedido=$params['fecha_pedido'];
		$m_solicitud->periodo_id=$params['periodo_id'];
		$m_solicitud->fecha_vigencia_desde=$params['fecha_vigencia_desde'];
		$m_solicitud->observaciones_asegurado=$params['observaciones_asegurado'];
		$m_solicitud->observaciones_compania=$params['observaciones_compania'];

			

		//Guarda el ID de las tablas asociadas
		$m_solicitud->poliza_valores_id = $m_poliza_valores->poliza_valores_id;
		$m_solicitud->poliza_detalle_id = $m_poliza_detalle->detalle_automotor_id;
		$m_solicitud->save();
		//Guardo Numero de Solicitud
		$m_solicitud->numero_solicitud = $m_solicitud->poliza_id ;
		$m_solicitud->save();

		} catch (Exception $e) {
			echo $e->getMessage();
		}
		return $solicitud;
	}

	public function saveDetallePago($solicitud,$params){

		//1. Borra los datos de pago
		Domain_DetallePago::deleteDetallePago($solicitud->getModelPoliza()->poliza_id);

		if($params['cuotas'] == 0){
			//guarda datos del pago en una sola cuota u otro tipo de pago
			return true;
		}



		for ($i = 1; $i <= $params['cuotas']; $i++) {
			$detalle_pago = new Model_DetallePago();
			$detalle_pago->poliza_id = $solicitud->getModelPoliza()->poliza_id;
			$detalle_pago->cuotas_id=$i;
			$detalle_pago->importe=$params['importe'];
			$detalle_pago->save();
		}
		return $detalle_pago;
	}
}

